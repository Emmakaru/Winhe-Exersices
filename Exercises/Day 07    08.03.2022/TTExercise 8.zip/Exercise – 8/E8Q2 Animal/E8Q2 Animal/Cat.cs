﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E8Q2_Animal
{
    internal class Cat : Mammal
    {
        public Cat(string name) : base(name)
        {
        }

        public void greets()
        {
            Console.WriteLine("Meow");
        }

        public override string toString()
        {
            return "Cat[" + base.toString() + "]";
        }
    }
}
