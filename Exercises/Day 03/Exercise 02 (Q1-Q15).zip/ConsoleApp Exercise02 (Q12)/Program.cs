﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_Exercise02__Q12_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double width, height, areaOfCircle;
            double perimeter;

            Console.WriteLine("Input the Rectangle Height : ");
            height = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("nput the Rectangle width : ");
            width = Convert.ToDouble(Console.ReadLine());


            perimeter = 2 * (height + width);
            areaOfCircle = height * width;

            Console.WriteLine("Rectangle Perimeter is : " + perimeter);
            Console.WriteLine("Area of a Rectangle is : " + areaOfCircle);

            Console.ReadKey();
        }
    }
}

