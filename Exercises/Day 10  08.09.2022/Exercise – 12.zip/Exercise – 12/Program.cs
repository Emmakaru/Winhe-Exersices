﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise___12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hi Dr.Lasantha!");

            //Console.WriteLine("Welcome to the Hospital!");


            //Get New Register 

            DoctorRegistry dr = new DoctorRegistry("Anuradhapura");
            Doctor d = new Doctor("Lasantha", "6789", "Kidney");
            dr.register(d);
            if (!dr.register(d))
            {
                Console.WriteLine("Already on list");
            }
        }
    }
}