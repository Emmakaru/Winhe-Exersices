﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP
{
    internal class Point3D
    {
        //declare varibles
        int z;

        //constructor for z varible
        public Point3D() : base()
        {
            z = 300;
        }

        //constructor any value
        public Point3D(int z)
        {
            this.z = z;
        }

        //method


    }
}
