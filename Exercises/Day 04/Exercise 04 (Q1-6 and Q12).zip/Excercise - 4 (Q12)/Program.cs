﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excercise___4__Q12_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var console = "Inputs";
            int number;
            var max = int.MinValue;
            var min = int.MaxValue;
            char choice;
            do
            {
                Console.Write("Enter the number ");
                number = (int)Convert.ToInt64(Console.ReadLine());
                if (number > max)
                {
                    max = number;
                }
                if (number < min)
                {
                    min = number;
                }
                Console.Write("Do you want to continue y/n? ");

                //need to fix
                choice = console.next()[0];
            } while (choice == 'y' || choice == 'Y');
            Console.WriteLine("Largest number: " + max.ToString());
            Console.WriteLine("Smallest number: " + min.ToString());
        }
    }
}