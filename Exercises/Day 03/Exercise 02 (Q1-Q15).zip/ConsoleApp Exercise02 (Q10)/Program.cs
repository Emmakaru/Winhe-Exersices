﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_Exercise02__Q10_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            String salesmanName;
            int salesmanNo, soldUnits;
            Double unitPrice, salesValue, finalSalary = 0, commision = 0;
            Double basicSalary = 25000;

            Console.WriteLine("Enter Salesman Number :");
            salesmanNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Salesman Name :");
            salesmanName = Console.ReadLine();
            Console.WriteLine("Enter Number of Units Sold :");
            soldUnits = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Unit Price :");
            unitPrice = Convert.ToDouble(Console.ReadLine());

            salesValue = unitPrice * soldUnits;
            if (salesValue > 50000)
            {
                commision = salesValue * 0.1;
                finalSalary = basicSalary + commision;
            }
            else
            {
                finalSalary = basicSalary;
            }

            Console.WriteLine("Salesman Number : " + salesmanNo);
            Console.WriteLine("Salesman Name : " + salesmanName);
            Console.WriteLine("Sales Value : " + salesValue);
            Console.WriteLine("Commision is : " + commision);
            Console.WriteLine("Final Salary is :" + finalSalary);

            Console.ReadKey();
        }
    }
}