﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP
{
    class Point
    {
        private int x;
        private int y;

        //constructor with no parameters
        public Point()
        {
            x = 100;
            y = 200;
        }

        //constructor with any two values with parameters
        public Point(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        //set method
        public void SetValues()
        {
            x = 1000;
            y = 2000;
        }

        //method to set any two values 
        public void SetValues(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        //setters
        public void SetValueX(int x)
        {
            this.x = x;
        }

        public void SetValueY(int x)
        {
            this.y = y;
        }

        //getters
        public int GetValueX()
        {
            return x;
        }

        public int GetValueY()
        {
            return y;
        }

    }
}
