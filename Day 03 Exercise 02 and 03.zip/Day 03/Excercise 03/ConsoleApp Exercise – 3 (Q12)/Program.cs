﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_Exercise___3__Q12_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] array1 = { 1, 4, 2, 8, 7 };
            int[] array2 = { 7, 5, 9, 1, 0, 2, 6 };

            //call intersect extension method.
            var intersect = array1.Intersect(array2);

            foreach (int value in intersect)
            {
                Console.WriteLine(value);
                Console.ReadKey();
            }
        }
    }
}
