﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise___6__Q5_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please Enter Numnbers to CHeck they are Equal Or Not");
            Console.WriteLine("");
            Console.Write("Input First number: ");
            var num1 = Convert.ToInt64(Console.ReadLine());
            Console.Write("Input Second number: ");
            var num2 = Convert.ToInt64(Console.ReadLine());
            Console.Write("Input Third number: ");
            var num3 = Convert.ToInt64(Console.ReadLine());
            Console.Write("Input Fourth number: ");
            var num4 = Convert.ToInt64(Console.ReadLine());
            if (num1 == num2 && num2 == num3 && num3 == num4)
            {
                Console.WriteLine("Numbers are equal.");
            }
            else
            {
                Console.WriteLine("Numbers are not equal!");
            }
            Console.ReadKey();
        }
    }
}
