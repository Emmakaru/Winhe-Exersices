﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise___12
{
    internal class Doctor
    {

        //declare vari
        string fullName;
        string registryNumber;
        string specialty;

        public Doctor(string fullName, string registryNumber, string specialty)
        {
            this.fullName = fullName;
            this.registryNumber = registryNumber;
            this.specialty = specialty;
        }

        //get name
        public string GetName()
        {
            return fullName;
        }

        //get registry
        public string GetRegistryNumber()
        {
            return registryNumber;
        }

        //get specialty
        public string GetSpecialty()
        {
            return specialty;
        }

        //
        public void SetName(string fullName)
        {
            this.fullName = fullName;
        }

        //
        public bool Equals(Doctor doctor)
        {
            if (this.registryNumber == doctor.registryNumber)
            {
                return true;
            }

            return false;
        }

        //
        public string toString()
        {
            return "Dr. " + fullName + ", Specialty : " + specialty;
        }
    }
}