﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_Excercise__3_Q5_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int j;

            Console.WriteLine("Enter the number for Multiplication Table : ");
            int number = Convert.ToInt32(Console.ReadLine());

            for (j = 1; j <= 12; j++)
            {
                Console.WriteLine("{0} X {1} = {2} ", number, j, number * j);
            }
            Console.ReadKey();
        }
    }
}