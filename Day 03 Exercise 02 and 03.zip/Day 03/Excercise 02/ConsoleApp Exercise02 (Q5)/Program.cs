﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_Exercise02__Q5_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Salesman Number");
            int number = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Salesman Name");
            string name = Console.ReadLine();

            Console.WriteLine("Enter Number of Units Sold");
            int numberOfUnits = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Unit Price");
            int unitPrice = Convert.ToInt32(Console.ReadLine());

            //Printing Salesman Report

            Console.WriteLine("Salesman Number : " + number);
            Console.WriteLine("Salesman Name : " + name);
            Console.WriteLine("Number of Units Sold : " + numberOfUnits);
            Console.WriteLine("Unit Price : " + unitPrice);
            Console.WriteLine("Sales Value : " + (numberOfUnits * unitPrice));

            Console.ReadLine();
        }
    }
}

