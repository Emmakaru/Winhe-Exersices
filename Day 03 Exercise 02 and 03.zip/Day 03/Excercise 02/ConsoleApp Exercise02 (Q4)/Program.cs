﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_Exercise02__Q4_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter First Number :");
            int firstNumber = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Second Number :");
            int secondNumber = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Addition of two numbers :" + (firstNumber + secondNumber));

            Console.ReadLine();
        }
    }
}
