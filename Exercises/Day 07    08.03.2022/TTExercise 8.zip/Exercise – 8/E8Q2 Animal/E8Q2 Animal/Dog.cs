﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E8Q2_Animal
{
    internal class Dog : Mammal
    {
        public Dog(string name) : base(name)
        {
        }

        public void greets()
        {
            Console.WriteLine("Woof");
        }

        public void greets(Dog dog)
        {
            Console.WriteLine("Woooof");
        }

        public override string toString()
        {
           return "Dog[" + base.toString() + "]";
        }
    }
}
