﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_Exercise___3__Q10_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for (int i= 1; i <=5; i++) //rows
            {
                for(int j= 1; j<=10; j++)  //colomns
                {
                    Console.Write("*");
                }
                Console.WriteLine();
                Console.ReadKey();
            }
        }
    }
}
