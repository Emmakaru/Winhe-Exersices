﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_Exercise02__Q13_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double height, surfaceArea, radius;
            double volume;
            double PI = 3.14;

            Console.WriteLine("Input the radius of the Cylinder : ");
            radius = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Input the Cylinder Height : ");
            height = Convert.ToDouble(Console.ReadLine());


            surfaceArea = (2 * PI * radius) * height;
            volume = (PI * radius * radius) * height;

            Console.WriteLine("Cylinder surfaceArea is : " + surfaceArea);
            Console.WriteLine("volume of a Cylinder is : " + volume);

            Console.ReadKey();
        }
    }
}
