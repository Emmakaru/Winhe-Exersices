﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise___6__Q9_
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int outer = 1;
            int inner = 1;
            int num = 1;
            int rows = 0;

            Console.Write("Enter the number of rows: ");
            rows = int.Parse(Console.ReadLine());

            //declared 4 variables outer, inner, num, and rows
            //read the value of rows from the user
            // outer loop is execute

            for (; outer <= rows; outer = outer + 1)
            {
                for (inner = 1; inner < outer + 1; inner++)
                {
                    Console.Write(num + " ");
                    num = num + 1;
                }
                Console.WriteLine();
            }
        }
    }
}