﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_Exercise02__Q9_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            String studentName;
            int studentNo;
            Double marks1, marks2, marks3, totalMarks, averageMarks;

            Console.WriteLine("Enter student Number :");
            studentNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter student Name :");
            studentName = Console.ReadLine();
            Console.WriteLine("Enter student Marks for module 1 :");
            marks1 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter student Marks for module 2 :");
            marks2 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter student Marks for module 3 :");
            marks3 = Convert.ToDouble(Console.ReadLine());

            totalMarks = marks1 + marks2 + marks3;
            averageMarks = totalMarks / 3;


            Console.WriteLine("Student Number : " + studentNo);
            Console.WriteLine("Student Name : " + studentName);
            Console.WriteLine("Total marks : " + totalMarks);
            Console.WriteLine("Average Marks : " + averageMarks);
            if (averageMarks <= 49)
            {
                Console.WriteLine("Grade is Fail");
            }
            else if (averageMarks <= 59)
            {
                Console.WriteLine("Grade is Pass");
            }
            else if (averageMarks <= 69)
            {
                Console.WriteLine("Grade is Credit");
            }
            else if (averageMarks <= 79)
            {
                Console.WriteLine("Grade is Very Good Pass");
            }
            else
            {
                Console.WriteLine("Grade is Distinction");
            }

            Console.ReadKey();

        }
    }
}
