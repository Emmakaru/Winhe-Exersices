﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_11
{
    public  class Captain
    {
        private int age;
        private string name;
        private int yearsOfExperiance;
        private int registeryNumber;

        public Captain(int age, string name, int yearsOfExperiance, int registeryNumber)
        {
            this.age = age;
            this.name = name;
            this.yearsOfExperiance = yearsOfExperiance;
            this.registeryNumber = registeryNumber;
        }
        public string getName()
        {
            return name;
        }

        public int getYearsOfExperience()
        {
            return yearsOfExperiance;
        }

        public bool equals(Captain captain)
        {
            if (captain.name == name && (captain.registeryNumber == this.registeryNumber))
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        public string toString()
        {

            string text = name + ", age: " + age + "\n" + "YoE: " + yearsOfExperiance + "\n" + "Registry: " + registeryNumber;
            return text;
        }
    }
}
