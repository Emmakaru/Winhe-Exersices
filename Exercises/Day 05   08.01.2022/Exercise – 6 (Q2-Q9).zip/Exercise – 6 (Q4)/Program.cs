﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise___6__Q4_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int inputValue;

            //get the user inputs
            Console.WriteLine("01.(101 + 4) / 3 * 5");
            Console.WriteLine("02.true && true");
            Console.WriteLine("03.false && true");
            Console.WriteLine("04.(false && false) || (true && true)");
            Console.WriteLine("05.(false || false) && (true && true)");

            Console.WriteLine();
            Console.Write("Enter number for get the result : ");
            inputValue = Convert.ToInt32(Console.ReadLine());

            if (inputValue == 1)
            {
                Console.WriteLine(((101 + 4) / 3 * 5));
            }
            else if (inputValue == 2)
            {
                Console.WriteLine(true && true);
            }
            else if (inputValue == 3)
            {
                Console.WriteLine(false && true);
            }
            else if (inputValue == 4)
            {
                Console.WriteLine(((false && false) || (true && true)));
            }
            else if (inputValue == 5)
            {
                Console.WriteLine(((false || false) && (true && true)));
            }
            else
            {
                Console.WriteLine("Invalid Input");
            }
            Console.ReadKey();
        }


    }
}