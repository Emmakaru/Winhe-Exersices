﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excercise___4__Q12_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int number = 0;
            int min = 0;
            int max = 0;
            int temp;

            while (number != -1)
            {
                Console.WriteLine("Enter a number (If you want to exit enter -1) : ");
                number = Convert.ToInt32(Console.ReadLine());
                temp = number;

                if (temp > max)
                {
                    max = temp;
                }
                if (temp < min)
                {
                    min = temp;
                }
            }

            Console.WriteLine("Maximum number is : " + max);
            Console.WriteLine("Minimum number is : " + min);

            Console.ReadKey();

        }
    }
}