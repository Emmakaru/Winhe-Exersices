﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise___6__Q7_
{
    internal class Program
    {
        //

        static void Main(string[] args)
        {


            Console.ReadKey();
        }

        //Declare an array of 10 integers

        static int[] ArrayDeclaration(int[] array)
        {
            int[] result = new int[10];
            return array;
        }

        //Accept elements of an array

        static int[] AcceptArrayElement(int[] array)
        {
            for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine("Enter a value : ");
                array[i] = Convert.ToInt32(Console.ReadLine());
            }

            return array;
        }

        //Display elements of an array

        static void DisplayArray(int[] array)
        {
            for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine(array[i] + " ");
            }
        }

        //Search the element within array given by user

        static Boolean SearchElementInArray(int[] array)
        {
            int inputValue;
            bool result = false;


            Console.WriteLine("Enter an element do you want to search : ");
            inputValue = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] == inputValue)
                {
                    result = true;
                    break;
                }
            }
            return result;
        }

        //Sort the array using bubble sort method

        static void SortArray(int[] array)
        {
            int temp;

            for (int i = 1; i < array.Length; i++)
            {
                for (int j = i; j > 0; j--)
                {
                    if (array[j] < array[j - 1])
                    {
                        temp = array[j];
                        array[j] = array[j - 1];
                        array[j - 1] = temp;
                    }
                }

            }
        }

    }
}
