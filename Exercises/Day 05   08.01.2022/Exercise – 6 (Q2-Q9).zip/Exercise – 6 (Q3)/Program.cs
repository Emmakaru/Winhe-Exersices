﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise___6__Q3_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //decleare the variables
            int result = 0;
            int count = 0;
            int[] array = new int[7]; 

            //get the user inputs
            for(int i = 0; i < array.Length; i++)
            {
                Console.Write("Enter a number : ");
                array[i] = Convert.ToInt32(Console.ReadLine());
            }

            //check zero index value is 20 
            if (array[0] == 20)
            {
                count++;
            }

            //check other indexes values
            for(int i = 1; i < array.Length; i++)
            {
                if (array[i-1] == 20  && array[i] == 20)
                {
                    result = 1;
                }

                if (array[i] == 20)
                {
                    count++;
                }

            }

            if(count == 3 && result == 0)
            {
                Console.WriteLine("The number 20 appears 3 times and no 20's are next to each other in a given array ");
            }
            else
            {
                Console.WriteLine("The array is not following required conditions");
            }

            Console.ReadKey();

        }
    }
}



