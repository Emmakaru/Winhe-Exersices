﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise___6__Q8_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //declare varibles
            int rawTotal = 0;
            int coloumTotal = 0;
            int total = 0;

            //get user input 
            Console.Write("Input the size of row and column of the table : ");
            int n = Convert.ToInt32(Console.ReadLine());

            int[,] metrix = new int[n, n];

            for (int i = 0; i < metrix.GetLength(0); i++)
            {
                for (int j = 0; j < metrix.GetLength(1); j++)
                {
                    Console.Write("Input numbers : ");
                    metrix[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            for (int i = 0; i < metrix.GetLength(0); i++)
            {
                coloumTotal = 0;
                for (int j = 0; j < metrix.GetLength(1); j++)
                {
                    Console.Write(metrix[i, j] + " ");
                    coloumTotal = coloumTotal + metrix[i, j];

                }
                Console.WriteLine(coloumTotal);
                total = total + coloumTotal;
            }

            for (int i = 0; i < metrix.GetLength(0); i++)
            {
                rawTotal = 0;
                for (int j = 0; j < metrix.GetLength(1); j++)
                {
                    rawTotal = rawTotal + metrix[j, i];
                }
                Console.Write(rawTotal + " ");
                total = total + rawTotal;
            }
            Console.Write(total);

            Console.ReadKey();

        }
    }
}