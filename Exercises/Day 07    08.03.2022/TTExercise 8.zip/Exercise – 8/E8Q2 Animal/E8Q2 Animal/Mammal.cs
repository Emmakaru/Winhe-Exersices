﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E8Q2_Animal
{
    internal class Mammal : Animal
    {
        public Mammal(string name) : base(name) 
        {

        }

        public override string toString()
        {
            string text = "Mammal: Mammel[" + base.toString() + "]";
            return text;
        }
    }
}
