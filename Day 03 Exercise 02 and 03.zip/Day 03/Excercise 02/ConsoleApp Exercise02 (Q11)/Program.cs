﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_Exercise02__Q11_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double radius, circumference, areaOfCircle;
            double PI = 3.14;

            Console.WriteLine("Input the radius of the circle : ");
            radius = Convert.ToDouble(Console.ReadLine());


            circumference = 2 * PI * radius;
            areaOfCircle = PI * radius * radius;

            Console.WriteLine("circle circumference is : " + circumference);
            Console.WriteLine("Area of a Circle is : " + areaOfCircle);

            Console.ReadKey();
        }
    }
}

