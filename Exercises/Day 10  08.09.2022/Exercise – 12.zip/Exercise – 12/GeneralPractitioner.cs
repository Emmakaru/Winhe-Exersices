﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise___12
{
    class GeneralPractitioner : Doctor
    {
        private string practiceName;
        private string address;

        public GeneralPractitioner(string practiceName, string address, string fullName, string registryNumber, string speciality) : base(fullName, registryNumber, speciality)
        {
            this.practiceName = practiceName;
            this.address = address;
        }

        public string toString()
        {
            return base.toString() + " , Practice: " + practiceName;
        }
    }
}