﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excercise___4__Q5_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //variable declaration
            int randomNumber;
            int userInputNumber;

            //genarate random number
            Random random = new Random();
            randomNumber = random.Next(0, 100);

            //user can try only seven time
            for (int i = 0; i < 7; i++)
            {
                //get user input number
                Console.Write("Guess the number between 0 - 100 : ");
                userInputNumber = Convert.ToInt32(Console.ReadLine());

                //check guess number conditions
                if (userInputNumber == randomNumber)
                {
                    Console.WriteLine("Congratulations !!!\nYou are correct");
                    break;
                }
                else if (userInputNumber > randomNumber)
                {
                    Console.WriteLine("Too high, try again!");
                }
                else
                {
                    Console.WriteLine("Too low, try again!");
                }

            }
            Console.WriteLine("Game Over\nThe Number is : " + randomNumber);

            Console.ReadKey();





        }
    }
}
