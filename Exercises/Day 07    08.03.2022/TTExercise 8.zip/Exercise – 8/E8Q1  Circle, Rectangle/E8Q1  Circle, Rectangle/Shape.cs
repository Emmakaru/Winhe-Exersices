﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E8Q1__Circle__Rectangle
{
    internal class Shape
    {
        private String color = "red";
        private bool filled = true;

        public Shape()
        {

        }
        public Shape(string color, bool filled)
        {
            this.color = color;
            this.filled = filled;
        }

        public String getColor() 
        { 
            return color; 
        }

        public void setColor(String color)
        {
            this.color = color;
        }

        public bool isFilled() 
        { 
            return filled; 
        }

        public void setFilled(bool filled)
        {
            this.filled = filled;
        }
        public string toString()
        {
            return "Shape[color = " + color + ", " + "filled = " + filled + "]";
        }

    }
}
