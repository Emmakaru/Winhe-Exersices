﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_11
{
    public class SailboatRunner
    {
        static void Main(string[] args)
        {
            Sailboat sailboat = new Sailboat(34, "jerry", "gd&g");
            Console.WriteLine(sailboat.toString());
            Captain cap = new Captain(24, "Lasantha", 2, 3443);
            Console.WriteLine();
            sailboat.assignCaption(cap);
            Console.WriteLine();
            Console.WriteLine(cap.toString());

            Console.ReadLine();
        }
    }
}
