﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise___6__Q6_
{
    internal class Program
    {
        static void pushZerosToRight(int[] arr, int n)
        {
            // Count of non-zero elements
            int count = 0;


            for (int i = 0; i < n; i++)
                if (arr[i] != 0)

                    // here count is incremented
                    arr[count++] = arr[i];


            while (count < n)
                arr[count++] = 0;
        }


        public static void Main()
        {
            int[] arr = { 1, 9, 8, 4, 0, 0, 2, 7, 0, 6, 0, 9 };

            Console.WriteLine("Original Array : ");
            foreach (int i in arr)
            {

                Console.Write("{0} ", i);
            }
            int n = arr.Length;
            pushZerosToRight(arr, n);
            Console.WriteLine("");
            Console.WriteLine("Array after pushing all zeros to the back : ");
            for (int i = 0; i < n; i++)
                Console.Write(arr[i] + " ");

            Console.ReadLine();
        }
    }
}

