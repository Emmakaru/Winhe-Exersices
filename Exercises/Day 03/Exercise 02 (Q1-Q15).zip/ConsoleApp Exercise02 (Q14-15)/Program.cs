﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_Exercise02__Q14_15_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double width, height, areaOfCircle;
            double perimeter;
            double radius, circumference;
            double PI = 3.14;
            double surfaceArea;
            double volume;
            int userChoice;

            Console.WriteLine("-------------- Select the choice and Type the number You want :-----------------");
            Console.WriteLine("1 - The area and the circumference of the circle");
            Console.WriteLine("2 - The perimeter and the area of the rectangle");
            Console.WriteLine("3 - The surface area and the volume of the cylinder");
            Console.WriteLine("0 - If you want to exit type zero");
            Console.WriteLine("---------------------------------------------------------------------------------");
            Console.Write("Input the Number above list : ");
            userChoice = Convert.ToInt32(Console.ReadLine());

            while (userChoice != 0)
            {

                if (userChoice == 1)
                {
                    Console.WriteLine("Input the radius of the circle : ");
                    radius = Convert.ToDouble(Console.ReadLine());


                    circumference = 2 * PI * radius;
                    areaOfCircle = PI * radius * radius;

                    Console.WriteLine("circle circumference is : " + circumference);
                    Console.WriteLine("Area of a Circle is : " + areaOfCircle);


                }
                else if (userChoice == 2)
                {
                    Console.WriteLine("Input the Rectangle Height : ");
                    height = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Input the Rectangle width : ");
                    width = Convert.ToDouble(Console.ReadLine());


                    perimeter = 2 * (height + width);
                    areaOfCircle = height * width;

                    Console.WriteLine("Rectangle Perimeter is : " + perimeter);
                    Console.WriteLine("Area of a Rectangle is : " + areaOfCircle);
                }
                else if (userChoice == 3)
                {
                    Console.WriteLine("Input the radius of the Cylinder : ");
                    radius = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Input the Cylinder Height : ");
                    height = Convert.ToDouble(Console.ReadLine());


                    surfaceArea = (2 * PI * radius) * height;
                    volume = (PI * radius * radius) * height;

                    Console.WriteLine("Cylinder surfaceArea is : " + surfaceArea);
                    Console.WriteLine("volume of a Cylinder is : " + volume);
                }
                else
                {
                    Console.WriteLine("Input Number is wrong Try again");
                }

                Console.Write("Input the Number above list : ");
                userChoice = Convert.ToInt32(Console.ReadLine());
            }

            Console.Write("Thank you");
            Console.ReadKey();

        }
    }
}
